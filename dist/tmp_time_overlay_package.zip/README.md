# TruckersMP时间显示插件

这是一个供 Euro Truck Simulator 2 / TruckersMP 使用的时间显示插件。时间和设置面板通过 DirectX 11 `Present` Hook 直接绘制在游戏帧内

```text
Current Time: 2026-Jul-29 17:57:44 UTC
```
## 游戏内设置面板

进入游戏后按 `Ctrl+F9` 打开或关闭中文 ImGui 设置面板。支持调整：

- 字体大小
- 距离画面底部的位置
- 水平位置
- 文字颜色
- `Current Time:` 前缀

首次启动时会在 DLL 旁边自动生成 `tmp_time_overlay.ini`。修改后点击“应用并保存”，下次启动会自动恢复设置。

## 安装

1. 完全退出 Euro Truck Simulator 2 和 TruckersMP。
2. 将 `tmp_time_overlay.dll` 放到：

   ```text
   <Euro Truck Simulator 2 安装目录>\bin\win_x64\plugins\
   ```

3. 需要创建 `plugins` 文件夹
4. 启动游戏；出现“检测到高级 SDK”提示时确认继续。
5. 按 `Ctrl+F9` 打开设置面板。

项目内固定包含 Dear ImGui 1.92.9（MIT）与 MinHook 1.3.4（BSD-2-Clause）的构建所需源码及许可证。
